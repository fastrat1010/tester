
package com.infosys.extservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.extservice.dto.AadharDTO;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.service.AadharServiceImpl;
import com.infosys.extservice.service.AadharServiceValidation;

@RestController
@RequestMapping("/aadhar")
public class AadharController {
	
	@Autowired 
	AadharServiceImpl aadharService;
	
	@Autowired 
	AadharServiceValidation aadharServiceValidation;
	
	@GetMapping(value = "/{phoneNo}")
	AadharDTO getValidAadharDetails(@PathVariable("phoneNo") String phoneNo)
		throws ExternalServiceException
	{
		aadharServiceValidation.isPhoneNoValid(phoneNo);
		AadharDTO aadharDTO = aadharService.getAadharDetails(phoneNo);
		return aadharDTO;
	}
	
	@GetMapping()
	Boolean ValidateAadhar(@RequestParam("aadharId")String aadharId,
			@RequestParam("firstName")String firstName,
			@RequestParam("lastName")String lastName)
		throws ExternalServiceException
	{
		aadharServiceValidation.isInputValid(aadharId, firstName, lastName);
		return aadharService.isAadharValid(aadharId, firstName, lastName);
	}

	@PutMapping(consumes = "application/json",value="/{aadharId}")
	AadharDTO updateAddress(@RequestBody AadharDTO aadharDTO, 
			@PathVariable("aadharId") String aadharId) throws ExternalServiceException
	{
		aadharServiceValidation.isInputValid(aadharId, "ABCD", "ABCD");
		String address = aadharDTO.getAddress();
		aadharServiceValidation.isAddressValid(address);
		aadharDTO = aadharService.updateAddress(aadharId, address);
		return aadharDTO;
	}
}
