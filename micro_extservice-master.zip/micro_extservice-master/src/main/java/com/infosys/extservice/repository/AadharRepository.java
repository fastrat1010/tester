package com.infosys.extservice.repository;
 

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

import com.infosys.extservice.entity.AadharMaster;

/**
 * The Interface AadharRepository.
 */
public interface AadharRepository extends JpaRepository<AadharMaster, String>{

	Optional<AadharMaster> getByPhoneNo(String phoneNo);
	Optional<AadharMaster> getByAddress(String address);
	
	@Transactional
	@Modifying
	@Query(value = "update aadhar_master set address = ? where aadharId = ?",nativeQuery=true)
	void updateAddress(String address, String aadharId);
	
}