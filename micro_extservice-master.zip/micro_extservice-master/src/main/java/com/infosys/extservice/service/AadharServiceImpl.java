package com.infosys.extservice.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.infosys.extservice.dto.AadharDTO;
import com.infosys.extservice.entity.AadharMaster;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.repository.AadharRepository;

@SuppressWarnings("unused")
@Service
public class AadharServiceImpl implements AadharService {

	
	@Autowired
	AadharRepository aadharRepository;
	
	@Autowired 
	AadharServiceValidation aadharServiceValidation;
	
	public boolean isAadharValid(String aadharId, String firstName, String lastName) throws ExternalServiceException {
	
		aadharServiceValidation.isInputValid(aadharId, firstName, lastName);
		Optional<AadharMaster> aadhar_opt = aadharRepository.findById(aadharId);
 		if( aadhar_opt.isPresent())
 		{
 			AadharMaster aadharMaster = aadhar_opt.get();
 			if(aadharMaster.getFirstName().contentEquals(firstName) &&
 					aadharMaster.getLastName().contentEquals(lastName))
 			{
 				return true;
 			}
 		}
 		
 		return false;
	}

	public AadharDTO getAadharDetails(String phoneNo) throws ExternalServiceException{
		aadharServiceValidation.isPhoneNoValid(phoneNo);
		if (!(phoneNo.matches("[0-9]{10}")))
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_PHONE_LENGTH_INVALID.toString());
		AadharMaster aadharMaster = aadharRepository.getByPhoneNo(phoneNo);
		if( aadharMaster == null)
 		{
 			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_PHONE_INVALID.toString());
 		}
		return aadharMaster.prepareEntity(aadharMaster);
	}

	public AadharDTO updateAddress(String aadharId, AadharDTO aadharDTO) throws ExternalServiceException {
		if (!(aadharId.matches("[0-9]{12}")))
			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_AADHAR_FORMAT_INVALID.toString());
		aadharServiceValidation.isAddressValid(aadharDTO.getAddress());
		Optional<AadharMaster> aadhar_opt = aadharRepository.findById(aadharId);
		if( ! aadhar_opt.isPresent())
 		{
 			throw new ExternalServiceException(ExceptionConstants.CUSTOMER_AADHAR_INVALID.toString());
 		}
		AadharMaster aadharMaster = aadhar_opt.get();
		aadharRepository.updateAddress(aadharDTO.getAddress(), aadharId);
		aadharMaster.setAddress(aadharDTO.getAddress());
		return aadharMaster.prepareEntity(aadharMaster);
	}
}
