/*
 * Decompiled with CFR 0.137.
 * 
 * Could not load the following classes:
 *  com.infosys.extservice.ExtserviceApplication
 *  com.infosys.extservice.dto.AadharDTO
 *  com.infosys.extservice.entity.AadharMaster
 *  com.infosys.extservice.exception.ExceptionConstants
 *  com.infosys.extservice.exception.ExternalServiceException
 *  com.infosys.extservice.repository.AadharRepository
 *  com.infosys.extservice.service.AadharServiceImpl
 *  com.infosys.extservice.service.AadharServiceValidation
 *  org.junit.Before
 *  org.junit.BeforeClass
 *  org.junit.Rule
 *  org.junit.Test
 *  org.junit.rules.ExpectedException
 *  org.junit.runner.RunWith
 *  org.mockito.InjectMocks
 *  org.mockito.Mockito
 *  org.mockito.MockitoAnnotations
 *  org.mockito.stubbing.OngoingStubbing
 *  org.springframework.boot.SpringBootConfiguration
 *  org.springframework.boot.test.context.SpringBootTest
 *  org.springframework.boot.test.mock.mockito.MockBean
 *  org.springframework.test.context.junit4.SpringRunner
 */
package com.infosys.extservice.service;

import com.infosys.extservice.ExtserviceApplication;
import com.infosys.extservice.dto.AadharDTO;
import com.infosys.extservice.entity.AadharMaster;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.repository.AadharRepository;
import com.infosys.extservice.service.AadharServiceImpl;
import com.infosys.extservice.service.AadharServiceValidation;
import java.util.Optional;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.boot.SpringBootConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(value=SpringRunner.class)
@SpringBootTest(classes={ExtserviceApplication.class})
@SpringBootConfiguration
public class AadharServiceTest {
    @MockBean
    AadharRepository aadharRepository;
    @MockBean
    AadharServiceValidation serviceValidation;
    @InjectMocks
    AadharServiceImpl aadharService;
    @Rule
    public ExpectedException e = ExpectedException.none();
    private static AadharMaster am;

    @BeforeClass
    public static void beforeClass() {
        am = new AadharMaster();
        am.setAadharId("123456789012");
        am.setFirstName("a");
        am.setLastName("b");
        am.setAddress("Pune");
        am.setPhoneNo("9898989898");
    }

    @Before
    public void initialise() {
        MockitoAnnotations.initMocks((Object)this);
    }

    @Test
    public void testIsInputValidWithInvalidAadharId() throws ExternalServiceException {
        Mockito.when((Object)this.serviceValidation.isInputValid(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(new Throwable[]{new ExternalServiceException(ExceptionConstants.CUSTOMER_AADHAR_FORMAT_INVALID.toString())});
        this.e.expect(ExternalServiceException.class);
        this.e.expectMessage(ExceptionConstants.CUSTOMER_AADHAR_FORMAT_INVALID.toString());
        this.aadharService.isAadharValid("1234567891447", "", "");
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isInputValid("1234567891447", "", "");
    }

    @Test
    public void testIsValidInputDetailsWithInvalidFirstName() throws ExternalServiceException {
        Mockito.when((Object)this.serviceValidation.isInputValid(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(new Throwable[]{new ExternalServiceException(ExceptionConstants.CUSTOMER_FIRSTNAME_INVALID.toString())});
        this.e.expect(ExternalServiceException.class);
        this.e.expectMessage(ExceptionConstants.CUSTOMER_FIRSTNAME_INVALID.toString());
        this.aadharService.isAadharValid("123456789144", "", "");
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isInputValid("123456789144", "", "");
    }

    @Test
    public void testIsValidInputDetailsWithInvalidLastName() throws ExternalServiceException {
        Mockito.when((Object)this.serviceValidation.isInputValid(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenThrow(new Throwable[]{new ExternalServiceException(ExceptionConstants.CUSTOMER_LASTNAME_INVALID.toString())});
        this.e.expect(ExternalServiceException.class);
        this.e.expectMessage(ExceptionConstants.CUSTOMER_LASTNAME_INVALID.toString());
        this.aadharService.isAadharValid("123456789144", "abhishek", "");
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isInputValid("123456789144", "abhishek", "");
    }

    @Test
    public void testIsValidAadharIdWithNull() throws ExternalServiceException {
        Mockito.when((Object)this.serviceValidation.isInputValid(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn((Object)true);
        Mockito.when((Object)this.aadharRepository.findById((Object)"1234567890")).thenReturn(Optional.empty());
        this.aadharService.isAadharValid("1234567890", "a", "b");
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isInputValid(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        ((AadharRepository)Mockito.verify((Object)this.aadharRepository)).findById((Object)Mockito.anyString());
    }

    @Test
    public void testIsValidAadharIdWithoutNull() throws ExternalServiceException {
        Mockito.when((Object)this.serviceValidation.isInputValid(Mockito.anyString(), Mockito.anyString(), Mockito.anyString())).thenReturn((Object)true);
        Mockito.when((Object)this.aadharRepository.findById((Object)"123456789012")).thenReturn(Optional.of(am));
        this.aadharService.isAadharValid("123456789012", "a", "b");
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isInputValid(Mockito.anyString(), Mockito.anyString(), Mockito.anyString());
        ((AadharRepository)Mockito.verify((Object)this.aadharRepository)).findById((Object)Mockito.anyString());
    }

    @Test
    public void testGetAadharDetails() {
        Mockito.when((Object)this.serviceValidation.isPhoneNoValid(Mockito.anyString())).thenReturn((Object)true);
        Mockito.when((Object)this.aadharRepository.getByPhoneNo(Mockito.anyString())).thenReturn((Object)am);
        this.aadharService.getAadharDetails("1234567890");
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isPhoneNoValid(Mockito.anyString());
        ((AadharRepository)Mockito.verify((Object)this.aadharRepository)).getByPhoneNo(Mockito.anyString());
    }

    @Test
    public void testGetAadharDetailsFail() {
        Mockito.when((Object)this.serviceValidation.isPhoneNoValid(Mockito.anyString())).thenReturn((Object)false);
        this.e.expect(ExternalServiceException.class);
        this.e.expectMessage(ExceptionConstants.CUSTOMER_PHONE_LENGTH_INVALID.toString());
        this.aadharService.getAadharDetails("12345678");
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isPhoneNoValid(Mockito.anyString());
    }

    @Test
    public void testGetAadharDetailsInvalidPhoneNo() {
        Mockito.when((Object)this.serviceValidation.isPhoneNoValid(Mockito.anyString())).thenReturn((Object)true);
        Mockito.when((Object)this.aadharRepository.getByPhoneNo(Mockito.anyString())).thenReturn(null);
        this.e.expect(ExternalServiceException.class);
        this.e.expectMessage(ExceptionConstants.CUSTOMER_PHONE_INVALID.toString());
        this.aadharService.getAadharDetails("1234567890");
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isPhoneNoValid(Mockito.anyString());
        ((AadharRepository)Mockito.verify((Object)this.aadharRepository)).getByPhoneNo(Mockito.anyString());
    }

    @Test
    public void testUpdateAddress() {
        Mockito.when((Object)this.serviceValidation.isAddressValid(Mockito.anyString())).thenReturn((Object)true);
        Mockito.when((Object)this.aadharRepository.findById((Object)Mockito.anyString())).thenReturn(Optional.of(am));
        Mockito.when((Object)((AadharMaster)this.aadharRepository.save((Object)((AadharMaster)Mockito.any(AadharMaster.class))))).thenReturn((Object)am);
        Mockito.when((Object)((AadharMaster)this.aadharRepository.saveAndFlush((Object)((AadharMaster)Mockito.any(AadharMaster.class))))).thenReturn((Object)am);
        this.aadharService.updateAddress(am.getAadharId(), AadharDTO.prepareDTO((AadharMaster)am));
        ((AadharServiceValidation)Mockito.verify((Object)this.serviceValidation)).isAddressValid(Mockito.anyString());
        ((AadharRepository)Mockito.verify((Object)this.aadharRepository)).findById((Object)Mockito.anyString());
    }

    @Test
    public void testUpdateAddressFail() {
        Mockito.when((Object)this.aadharRepository.findById((Object)Mockito.anyString())).thenReturn(Optional.of(am));
        Mockito.when((Object)((AadharMaster)this.aadharRepository.saveAndFlush((Object)((AadharMaster)Mockito.any(AadharMaster.class))))).thenReturn((Object)am);
        this.e.expect(ExternalServiceException.class);
        this.e.expectMessage(ExceptionConstants.CUSTOMER_AADHAR_FORMAT_INVALID.toString());
        this.aadharService.updateAddress("1234567890", AadharDTO.prepareDTO((AadharMaster)am));
        ((AadharRepository)Mockito.verify((Object)this.aadharRepository)).findById((Object)Mockito.anyString());
    }
}

