/*
 * Decompiled with CFR 0.137.
 * 
 * Could not load the following classes:
 *  com.infosys.extservice.ExtserviceApplication
 *  org.junit.Assert
 *  org.junit.Test
 *  org.junit.runner.RunWith
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
 *  org.springframework.boot.test.context.SpringBootTest
 *  org.springframework.cloud.client.ServiceInstance
 *  org.springframework.cloud.client.discovery.DiscoveryClient
 *  org.springframework.test.annotation.DirtiesContext
 *  org.springframework.test.context.junit4.SpringRunner
 */
package com.infosys.extservice;

import com.infosys.extservice.ExtserviceApplication;
import java.util.List;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.client.discovery.DiscoveryClient;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.SpringRunner;

@AutoConfigureMockMvc
@RunWith(value=SpringRunner.class)
@SpringBootTest(classes={ExtserviceApplication.class})
@DirtiesContext
public class AadharDiscoveryTest {
    @Autowired
    DiscoveryClient discoveryClient;

    @Test
    public void testAadharServiceName() {
        List services = this.discoveryClient.getInstances("AadharMS");
        boolean found = false;
        for (ServiceInstance s : services) {
            String sName = s.getServiceId();
            if (!sName.equalsIgnoreCase("AadharMS")) continue;
            found = true;
        }
        Assert.assertTrue((boolean)found);
    }
}

