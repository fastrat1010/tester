/*
 * Decompiled with CFR 0.137.
 * 
 * Could not load the following classes:
 *  com.infosys.extservice.EurekaApplication
 *  com.infosys.extservice.ExtserviceApplication
 *  org.junit.Assert
 *  org.junit.Test
 *  org.junit.runner.RunWith
 *  org.springframework.test.context.junit4.SpringRunner
 */
package com.infosys.extservice;

import com.infosys.extservice.EurekaApplication;
import com.infosys.extservice.ExtserviceApplication;
import java.lang.annotation.Annotation;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(value=SpringRunner.class)
public class EurekaApiServerTest {
    @Test
    public void testEureka() {
        Class<EurekaApplication> apiClass = EurekaApplication.class;
        Annotation[] aArray = apiClass.getAnnotations();
        boolean found = false;
        for (Annotation a : aArray) {
            if (!a.toString().equals("@org.springframework.cloud.netflix.eureka.server.EnableEurekaServer()")) continue;
            found = true;
            break;
        }
        Assert.assertTrue((boolean)found);
    }

    @Test
    public void testEurekaAadharClient() {
        Class<ExtserviceApplication> apiClass = ExtserviceApplication.class;
        Annotation[] aArray = apiClass.getAnnotations();
        boolean found = false;
        for (Annotation a : aArray) {
            if (a.toString().equals("@org.springframework.cloud.netflix.eureka.EnableEurekaClient()")) {
                found = true;
                continue;
            }
            if (!a.toString().equals("@org.springframework.cloud.client.discovery.EnableDiscoveryClient(autoRegister=true)")) continue;
            found = true;
        }
        Assert.assertTrue((boolean)found);
    }
}

