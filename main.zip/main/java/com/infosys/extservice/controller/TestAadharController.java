/*
 * Decompiled with CFR 0.137.
 * 
 * Could not load the following classes:
 *  com.fasterxml.jackson.databind.ObjectMapper
 *  com.infosys.extservice.ExtserviceApplication
 *  com.infosys.extservice.controller.AadharController
 *  com.infosys.extservice.dto.AadharDTO
 *  com.infosys.extservice.exception.ExceptionConstants
 *  com.infosys.extservice.exception.ExternalServiceException
 *  com.infosys.extservice.service.AadharService
 *  org.hamcrest.CoreMatchers
 *  org.hamcrest.Matcher
 *  org.junit.Before
 *  org.junit.BeforeClass
 *  org.junit.Test
 *  org.junit.runner.RunWith
 *  org.mockito.Mockito
 *  org.mockito.stubbing.OngoingStubbing
 *  org.springframework.beans.factory.annotation.Autowired
 *  org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc
 *  org.springframework.boot.test.context.SpringBootTest
 *  org.springframework.boot.test.context.SpringBootTest$WebEnvironment
 *  org.springframework.boot.test.mock.mockito.MockBean
 *  org.springframework.http.MediaType
 *  org.springframework.test.context.junit4.SpringJUnit4ClassRunner
 *  org.springframework.test.web.servlet.MockMvc
 *  org.springframework.test.web.servlet.RequestBuilder
 *  org.springframework.test.web.servlet.ResultActions
 *  org.springframework.test.web.servlet.ResultMatcher
 *  org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder
 *  org.springframework.test.web.servlet.request.MockMvcRequestBuilders
 *  org.springframework.test.web.servlet.result.MockMvcResultMatchers
 *  org.springframework.test.web.servlet.setup.MockMvcBuilders
 *  org.springframework.web.context.WebApplicationContext
 */
package com.infosys.extservice.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.infosys.extservice.ExtserviceApplication;
import com.infosys.extservice.controller.AadharController;
import com.infosys.extservice.dto.AadharDTO;
import com.infosys.extservice.exception.ExceptionConstants;
import com.infosys.extservice.exception.ExternalServiceException;
import com.infosys.extservice.service.AadharService;
import org.hamcrest.CoreMatchers;
import org.hamcrest.Matcher;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.stubbing.OngoingStubbing;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

@RunWith(value=SpringJUnit4ClassRunner.class)
@SpringBootTest(webEnvironment=SpringBootTest.WebEnvironment.RANDOM_PORT, classes={AadharController.class, ExtserviceApplication.class})
@AutoConfigureMockMvc
public class TestAadharController {
    @Autowired
    private WebApplicationContext ctx;
    @Autowired
    private MockMvc mockMvc;
    @MockBean
    AadharService aadharService;
    private static AadharDTO aadharDTO;

    @Before
    public void setUp() {
        this.mockMvc = MockMvcBuilders.webAppContextSetup((WebApplicationContext)this.ctx).build();
    }

    @BeforeClass
    public static void beforeClass() {
        aadharDTO = new AadharDTO();
        aadharDTO.setAadharId("112233445566");
        aadharDTO.setFirstName("Tyrion");
        aadharDTO.setLastName("Lannister");
        aadharDTO.setAddress("Mumbai");
        aadharDTO.setPhoneNo("9898989898");
    }

    @Test
    public void testValidateAadharId() throws Exception {
        String id = "112233445566";
        Mockito.when((Object)this.aadharService.isAadharValid(id, "Tyrion", "Lannister")).thenReturn((Object)true);
        this.mockMvc.perform((RequestBuilder)MockMvcRequestBuilders.get((String)"/aadhar?aadharId={id}&firstName=Tyrion&lastName=Lannister", (Object[])new Object[]{id}).accept(new MediaType[]{MediaType.APPLICATION_JSON})).andExpect(MockMvcResultMatchers.status().is2xxSuccessful());
        ((AadharService)Mockito.verify((Object)this.aadharService)).isAadharValid(id, "Tyrion", "Lannister");
    }

    @Test
    public void testGetCustomer() throws Exception {
        String phoneNo = "112233445566";
        Mockito.when((Object)this.aadharService.getAadharDetails(phoneNo)).thenReturn((Object)aadharDTO);
        this.mockMvc.perform((RequestBuilder)MockMvcRequestBuilders.get((String)("/aadhar/" + phoneNo), (Object[])new Object[0])).andExpect(MockMvcResultMatchers.status().isOk()).andExpect(MockMvcResultMatchers.jsonPath((String)"$.aadharId", (Matcher)CoreMatchers.is((Object)aadharDTO.getAadharId()))).andExpect(MockMvcResultMatchers.jsonPath((String)"$.firstName", (Matcher)CoreMatchers.is((Object)aadharDTO.getFirstName()))).andExpect(MockMvcResultMatchers.jsonPath((String)"$.lastName", (Matcher)CoreMatchers.is((Object)aadharDTO.getLastName())));
        ((AadharService)Mockito.verify((Object)this.aadharService)).getAadharDetails(phoneNo);
    }

    @Test
    public void testInvalidAadharLength() throws Exception {
        String id = "1122334455";
        Mockito.when((Object)this.aadharService.isAadharValid(id, "Tyrion", "Lannister")).thenThrow(new Throwable[]{new ExternalServiceException(ExceptionConstants.CUSTOMER_AADHAR_FORMAT_INVALID.toString())});
        this.mockMvc.perform((RequestBuilder)MockMvcRequestBuilders.get((String)"/aadhar?aadharId={id}&firstName=Tyrion&lastName=Lannister", (Object[])new Object[]{id}).accept(new MediaType[]{MediaType.APPLICATION_JSON})).andExpect(MockMvcResultMatchers.status().is4xxClientError());
        ((AadharService)Mockito.verify((Object)this.aadharService)).isAadharValid(id, "Tyrion", "Lannister");
    }

    @Test
    public void testAddressUpdate() throws Exception {
        String id = "112233445566";
        AadharDTO newDTO = new AadharDTO();
        newDTO.setAddress("Pune");
        String json = new ObjectMapper().writeValueAsString((Object)newDTO);
        Mockito.when((Object)this.aadharService.updateAddress(id, newDTO)).thenReturn((Object)aadharDTO);
        this.mockMvc.perform((RequestBuilder)MockMvcRequestBuilders.put((String)("/aadhar/" + id), (Object[])new Object[0]).contentType("application/json").content(json)).andExpect(MockMvcResultMatchers.status().isOk());
        ((AadharService)Mockito.verify((Object)this.aadharService)).updateAddress(Mockito.anyString(), (AadharDTO)Mockito.any(AadharDTO.class));
    }
}

