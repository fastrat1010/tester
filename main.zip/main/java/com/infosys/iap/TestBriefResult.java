/*
 * Decompiled with CFR 0.137.
 */
package com.infosys.iap;

public class TestBriefResult {
    private String emailId;
    private int certificationId;
    private Object[] modules;

    public String getEmailId() {
        return this.emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    public int getCertificationId() {
        return this.certificationId;
    }

    public void setCertificationId(int certificationId) {
        this.certificationId = certificationId;
    }

    public Object[] getModules() {
        return this.modules;
    }

    public void setModules(Object[] objects) {
        this.modules = objects;
    }
}

