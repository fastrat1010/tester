/*
 * Decompiled with CFR 0.137.
 */
package com.infosys.iap;

public class TestResult {
    String moduleName;
    int totalNoOfTestCases;
    int noOfTestCasesPassed;
    int noOfTestCasesFailed;

    public String getModuleName() {
        return this.moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName;
    }

    public int getTotalTests() {
        return this.totalNoOfTestCases;
    }

    public void setTotalTests(int totalTests) {
        this.totalNoOfTestCases = totalTests;
    }

    public int getPassedTests() {
        return this.noOfTestCasesPassed;
    }

    public void setPassedTests(int passedTests) {
        this.noOfTestCasesPassed = passedTests;
    }

    public int getFailedTests() {
        return this.noOfTestCasesFailed;
    }

    public void setFailedTests(int failedTests) {
        this.noOfTestCasesFailed = failedTests;
    }

    public String toString() {
        return "TestResult [moduleName=" + this.moduleName + ", totalTests=" + this.totalNoOfTestCases + ", passedTests=" + this.noOfTestCasesPassed + ", failedTests=" + this.noOfTestCasesFailed + "]";
    }
}

