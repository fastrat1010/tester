/*
 * Decompiled with CFR 0.137.
 * 
 * Could not load the following classes:
 *  org.junit.runner.Description
 *  org.junit.runner.Result
 *  org.junit.runner.notification.Failure
 *  org.junit.runner.notification.RunListener
 */
package com.infosys.iap;

import com.infosys.iap.TestResult;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.runner.Description;
import org.junit.runner.Result;
import org.junit.runner.notification.Failure;
import org.junit.runner.notification.RunListener;

public class TestListener
extends RunListener {
    public Map<String, TestResult> output = new HashMap<String, TestResult>();
    List<String> mList = new ArrayList<String>();

    public void testFinished(Description description) throws Exception {
        TestResult tstResult = this.output.get(description.getClassName());
        if (tstResult == null) {
            tstResult = new TestResult();
            tstResult.setModuleName(description.getClassName().substring(description.getClassName().lastIndexOf(".") + 1));
            this.output.put(description.getClassName(), tstResult);
        }
        tstResult.setPassedTests(tstResult.getPassedTests() + 1);
        tstResult.setTotalTests(tstResult.getTotalTests() + 1);
    }

    public void testFailure(Failure failure) throws Exception {
        TestResult tstResult = this.output.get(failure.getDescription().getClassName());
        this.mList.add(failure.getDescription().getMethodName());
        if (tstResult == null) {
            tstResult = new TestResult();
            String classname = failure.getDescription().getClassName();
            tstResult.setModuleName(classname.substring(classname.lastIndexOf(".") + 1));
            this.output.put(failure.getDescription().getClassName(), tstResult);
        }
        tstResult.setFailedTests(tstResult.getFailedTests() + 1);
        tstResult.setPassedTests(tstResult.getPassedTests() - 1);
    }

    public void testRunFinished(Result result) throws Exception {
        super.testRunFinished(result);
        System.out.println("failure count:" + result.getFailureCount());
        System.out.println("run count:" + result.getRunCount());
    }
}

