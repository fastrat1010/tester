/*
 * Decompiled with CFR 0.137.
 * 
 * Could not load the following classes:
 *  com.google.gson.Gson
 *  com.google.gson.GsonBuilder
 *  org.junit.runner.JUnitCore
 *  org.junit.runner.Result
 *  org.junit.runner.notification.RunListener
 */
package com.infosys.iap;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.infosys.iap.TestBriefResult;
import com.infosys.iap.TestListener;
import com.infosys.iap.TestResult;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PrintStream;
import java.io.Writer;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.BiConsumer;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.notification.RunListener;

public class RunTests {
    public static void main(String[] args) throws Exception {
        Properties prop = new Properties();
        InputStream input = null;
        String filename = "user_output.json";
        String filename2 = "test_analyze.html";
        JUnitCore core = new JUnitCore();
        TestListener listener = new TestListener();
        core.addListener((RunListener)listener);
        input = RunTests.class.getClassLoader().getResourceAsStream("testcases.properties");
        prop.load(input);
        Class[] testClasses = new RunTests().getValues("iap.testcases", prop);
        core.run(new Class[]{testClasses[0], testClasses[1], testClasses[2], testClasses[3]});
        listener.output.forEach((k, v) -> System.out.println(String.valueOf(k) + ":" + v));
        core.removeListener((RunListener)listener);
        if (args != null && args.length == 1) {
            filename = args[0];
            filename2 = "/root/Desktop/test_analyze.html";
        }
        if (listener.mList.size() > 0) {
            RunTests.createTestAnalyze(filename2, listener.mList);
        }
        RunTests.writeJsonfile(listener.output, filename);
        System.exit(0);
    }

    private static void createTestAnalyze(String filename2, List<String> mList) {
        try {
            InputStream input2 = RunTests.class.getClassLoader().getResourceAsStream("messages.properties");
            Properties prop2 = new Properties();
            prop2.load(input2);
            StringBuilder htmlStringBuilder = new StringBuilder();
            htmlStringBuilder.append("<html><body> ");
            htmlStringBuilder.append("<head>  <style>   table {  border-collapse: collapse; width: 100%;  }");
            htmlStringBuilder.append(" th, td {  text-align: left;  padding: 8px;  }");
            htmlStringBuilder.append("  tr:nth-child(even) { background-color: #D3D3D3; }  </style>  </head>");
            htmlStringBuilder.append("<div style=\"padding-left:200px; width:800px\" >");
            htmlStringBuilder.append(" <h2 style=\"background-color:green;\"><font color=\"white\">");
            htmlStringBuilder.append(prop2.getProperty("qpname"));
            htmlStringBuilder.append("</font></h2> ");
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String formatDateTime = LocalDateTime.now().format(formatter);
            htmlStringBuilder.append("<h5>").append(formatDateTime).append(" </h5>");
            htmlStringBuilder.append("<table border=\"0\" bordercolor=\"#000000\">");
            for (String i : mList) {
                htmlStringBuilder.append("<tr><td><li>");
                htmlStringBuilder.append(prop2.getProperty(i));
                htmlStringBuilder.append("</li></td></tr>");
            }
            htmlStringBuilder.append("</ul></table></div></body></html>");
            RunTests.writetofile(htmlStringBuilder.toString(), filename2);
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private static void writeJsonfile(Map<String, TestResult> output, String filename) {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        TestBriefResult result = new TestBriefResult();
        result.setEmailId("test@infy");
        result.setCertificationId(1004);
        result.setModules(output.values().toArray());
        System.out.println(gson.toJson((Object)result));
        try {
            Throwable throwable = null;
            Object var6_8 = null;
            try {
                FileWriter file = new FileWriter(new File(filename));
                try {
                    file.write(gson.toJson((Object)result));
                    file.flush();
                }
                finally {
                    if (file != null) {
                        file.close();
                    }
                }
            }
            catch (Throwable throwable2) {
                if (throwable == null) {
                    throwable = throwable2;
                } else if (throwable != throwable2) {
                    throwable.addSuppressed(throwable2);
                }
                throw throwable;
            }
        }
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Class[] getValues(String key, Properties properties) throws Exception {
        Class[] classArray = new Class[10];
        String list = properties.getProperty(key);
        ArrayList<String> strClasses = new ArrayList<String>(Arrays.asList(list.split(",")));
        Object[] objArray = strClasses.toArray();
        for (int i = 0; i < objArray.length; ++i) {
            String className = objArray[i].toString();
            classArray[i] = Class.forName(className);
        }
        return classArray;
    }

    private static void writetofile(String a, String filename) throws IOException {
        File file = new File(filename);
        FileOutputStream outputStream = new FileOutputStream(file.getAbsoluteFile());
        OutputStreamWriter writer = new OutputStreamWriter(outputStream);
        writer.write(a);
        ((Writer)writer).close();
    }
}

